import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { MASTER_ADMIN_EMAIL, PLAN_CONFIGS, PlanTier } from '../../types';
import {
  Crown,
  Briefcase,
  User,
  ShieldCheck,
  CheckCircle2,
  Sparkles,
  ArrowLeft,
  Building2,
  Lock,
  ExternalLink,
  ChevronRight,
  Zap,
  Globe,
  Loader2,
  AlertCircle,
  HelpCircle,
} from 'lucide-react';

interface LoginScreenProps {
  onDismiss?: () => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onDismiss }) => {
  const {
    authUser,
    signInWithGoogle,
    signInAsMasterDemo,
    signInAsBusinessOwnerDemo,
    signOutUser,
    businesses,
    clients,
    setActiveClientId,
    setRole,
  } = useApp();

  const [activeLoginTab, setActiveLoginTab] = useState<'google' | 'master' | 'business' | 'client'>('google');
  const [selectedBizId, setSelectedBizId] = useState<string>(businesses[0]?.id || '');
  const [selectedClientId, setSelectedClientId] = useState<string>(clients[0]?.id || '');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleGoogleSignIn = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    const res = await signInWithGoogle();
    setIsLoading(false);
    if (!res.success) {
      setErrorMessage(res.error || 'ההתחברות לא הושלמה. בדוק הרשאות דפדפן לחלון קופץ.');
    } else {
      if (onDismiss) onDismiss();
    }
  };

  const handleMasterDemoLogin = () => {
    signInAsMasterDemo();
    if (onDismiss) onDismiss();
  };

  const handleBusinessDemoLogin = () => {
    if (selectedBizId) {
      signInAsBusinessOwnerDemo(selectedBizId);
      if (onDismiss) onDismiss();
    }
  };

  const handleClientPortalLogin = () => {
    if (selectedClientId) {
      const client = clients.find((c) => c.id === selectedClientId);
      if (client) {
        setActiveClientId(client.id);
        setRole('client');
        if (onDismiss) onDismiss();
      }
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col justify-between selection:bg-indigo-500 selection:text-white relative overflow-x-hidden font-sans" dir="rtl">
      {/* Background Ambience / Glow */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-indigo-600/20 rounded-full blur-3xl pointer-events-none -z-10" />
      <div className="absolute bottom-10 left-1/4 w-96 h-96 bg-purple-600/15 rounded-full blur-3xl pointer-events-none -z-10" />

      {/* Top Navbar */}
      <header className="border-b border-slate-800/80 bg-slate-950/60 backdrop-blur-md px-4 sm:px-8 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-linear-to-br from-indigo-500 via-indigo-600 to-slate-900 flex items-center justify-center text-white font-extrabold text-xl shadow-lg shadow-indigo-500/25">
              T
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-lg tracking-tight text-white">TALTOR</span>
                <span className="text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-400/30 px-2 py-0.5 rounded-full">
                  CRM Cloud
                </span>
              </div>
              <span className="text-xs text-slate-400 hidden sm:inline">מערכת ניהול לקוחות מתקדמת רב-שכבתית</span>
            </div>
          </div>

          {onDismiss && (
            <button
              onClick={onDismiss}
              className="text-xs font-bold text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-700 px-3.5 py-2 rounded-xl transition-all border border-slate-700 flex items-center gap-1.5"
            >
              <span>המשך למערכת</span>
              <ArrowLeft className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-5xl w-full mx-auto px-4 sm:px-6 py-8 sm:py-12 flex flex-col justify-center">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Left Column: Branding & Features Pitch (Desktop & Tablet) */}
          <div className="lg:col-span-6 space-y-6 text-right">
            <div className="inline-flex items-center gap-2 bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-semibold px-3 py-1 rounded-full">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>ניהול מאסטר עליון • 3 חבילות שירות • פורטל אישי</span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight leading-tight">
              פורטל ההתחברות <br />
              <span className="bg-linear-to-r from-indigo-400 via-purple-300 to-pink-400 bg-clip-text text-transparent">
                למערכת TALTOR
              </span>
            </h1>

            <p className="text-sm text-slate-300 leading-relaxed max-w-xl">
              מערכת ענן רב-שכבתית מודרנית המאפשרת למנהל המאסטר שליטה מלאה בכלל בעלי העסקים, מסלולי המנויים, והתקבולים הכספיים — לצד סביבת עבודה חכמה לכל עסק ופורטל לקוחות קצה ייעודי.
            </p>

            {/* 3 Tier Summary Badges */}
            <div className="grid grid-cols-3 gap-2.5 pt-2">
              {(['BASIC', 'PRO', 'ULTIMATE'] as PlanTier[]).map((tier) => {
                const conf = PLAN_CONFIGS[tier];
                return (
                  <div
                    key={tier}
                    className={`p-3 rounded-xl border text-right transition-all ${
                      tier === 'ULTIMATE'
                        ? 'bg-amber-950/40 border-amber-500/40'
                        : tier === 'PRO'
                        ? 'bg-indigo-950/40 border-indigo-500/40'
                        : 'bg-slate-800/40 border-slate-700/60'
                    }`}
                  >
                    <span className="block text-[11px] font-bold text-slate-300">{conf.nameHe}</span>
                    <span className="text-base font-black text-white">₪{conf.pricePerMonth}</span>
                    <span className="text-[10px] text-slate-400 block mt-0.5">
                      {tier === 'BASIC' ? 'עד 50 לקוחות' : tier === 'PRO' ? 'משפך + שיווק' : 'ללא הגבלה + AI'}
                    </span>
                  </div>
                );
              })}
            </div>

            {/* Trust highlights */}
            <div className="pt-2 flex flex-wrap items-center gap-4 text-xs text-slate-400">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Google OAuth 2.0 מאובטח</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>סנכרון ענן Firebase בזמן אמת</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>הפרדת נתונים מוחלטת (Multi-Tenant)</span>
              </div>
            </div>
          </div>

          {/* Right Column: Interactive Login Box */}
          <div className="lg:col-span-6">
            <div className="bg-slate-950/80 backdrop-blur-xl border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-indigo-950/50 space-y-6">
              {/* Header inside card */}
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-4">
                <div>
                  <h2 className="text-lg font-bold text-white">התחברות לחשבונך</h2>
                  <p className="text-xs text-slate-400 mt-0.5">בחר את אופן ההתחברות המתאים לך</p>
                </div>
                <div className="w-9 h-9 rounded-xl bg-slate-800 text-indigo-400 flex items-center justify-center">
                  <Lock className="w-4 h-4" />
                </div>
              </div>

              {/* Status if already authenticated */}
              {authUser && (
                <div className="bg-slate-900/90 border border-slate-700/80 rounded-2xl p-4 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    {authUser.photoURL ? (
                      <img
                        src={authUser.photoURL}
                        alt={authUser.displayName || 'משתמש'}
                        className="w-10 h-10 rounded-full border-2 border-indigo-500 object-cover"
                      />
                    ) : (
                      <div className="w-10 h-10 rounded-full bg-indigo-600 text-white font-bold flex items-center justify-center">
                        {authUser.displayName?.charAt(0) || 'U'}
                      </div>
                    )}
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-white">{authUser.displayName}</span>
                        {authUser.isMaster && (
                          <span className="bg-amber-400/20 text-amber-300 border border-amber-400/40 text-[10px] font-bold px-2 py-0.2 rounded-full flex items-center gap-1">
                            <Crown className="w-3 h-3 text-amber-400" />
                            <span>מאסטר</span>
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-slate-400 font-mono">{authUser.email}</span>
                    </div>
                  </div>

                  <button
                    onClick={async () => {
                      await signOutUser();
                    }}
                    className="text-xs text-red-400 hover:text-red-300 font-bold px-3 py-1.5 rounded-lg border border-red-500/30 hover:bg-red-500/10 transition-colors"
                  >
                    התנתק
                  </button>
                </div>
              )}

              {/* Mode Switcher Tabs */}
              <div className="grid grid-cols-4 gap-1 bg-slate-900/90 p-1 rounded-xl border border-slate-800 text-[11px] font-bold text-center">
                <button
                  type="button"
                  onClick={() => setActiveLoginTab('google')}
                  className={`py-2 px-1 rounded-lg transition-all flex flex-col items-center gap-1 cursor-pointer ${
                    activeLoginTab === 'google'
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  <svg viewBox="0 0 24 24" className="w-3.5 h-3.5 fill-current">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 14h2v2h-2v-2zm0-10h2v8h-2V6z"/>
                  </svg>
                  <span>Google</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveLoginTab('master')}
                  className={`py-2 px-1 rounded-lg transition-all flex flex-col items-center gap-1 cursor-pointer ${
                    activeLoginTab === 'master'
                      ? 'bg-amber-500 text-amber-950 shadow-xs font-black'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  <Crown className="w-3.5 h-3.5" />
                  <span>מאסטר</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveLoginTab('business')}
                  className={`py-2 px-1 rounded-lg transition-all flex flex-col items-center gap-1 cursor-pointer ${
                    activeLoginTab === 'business'
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  <Briefcase className="w-3.5 h-3.5" />
                  <span>בעל עסק</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveLoginTab('client')}
                  className={`py-2 px-1 rounded-lg transition-all flex flex-col items-center gap-1 cursor-pointer ${
                    activeLoginTab === 'client'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  <User className="w-3.5 h-3.5" />
                  <span>פורטל לקוח</span>
                </button>
              </div>

              {/* Tab 1: Google OAuth Login */}
              {activeLoginTab === 'google' && (
                <div className="space-y-4">
                  <p className="text-xs text-slate-300">
                    התחבר באמצעות חשבון Google הרשמי. המערכת תזהה אותך לפי כתובת האימייל ותנתב אותך ישירות להרשאה המתאימה (מנהל מאסטר או בעל עסק).
                  </p>

                  <button
                    onClick={handleGoogleSignIn}
                    disabled={isLoading}
                    className="w-full bg-white hover:bg-slate-100 text-slate-900 font-extrabold py-3.5 px-4 rounded-xl transition-all flex items-center justify-center gap-3 shadow-lg hover:shadow-indigo-500/10 cursor-pointer disabled:opacity-50 min-h-[44px]"
                  >
                    {isLoading ? (
                      <Loader2 className="w-5 h-5 animate-spin text-indigo-600" />
                    ) : (
                      <svg viewBox="0 0 24 24" className="w-5 h-5">
                        <path
                          fill="#4285F4"
                          d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.8-2.4 3.66v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.15z"
                        />
                        <path
                          fill="#34A853"
                          d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.76-2.1-6.71-4.93H1.24v3.15C3.26 21.36 7.36 24 12 24z"
                        />
                        <path
                          fill="#FBBC05"
                          d="M5.29 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.24C.45 8.16 0 9.94 0 12s.45 3.84 1.24 5.42l4.05-3.15z"
                        />
                        <path
                          fill="#EA4335"
                          d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.36 0 3.26 2.64 1.24 6.58l4.05 3.15c.95-2.83 3.59-4.98 6.71-4.98z"
                        />
                      </svg>
                    )}
                    <span className="text-sm">התחברות מהירה באמצעות חשבון Google</span>
                  </button>

                  {errorMessage && (
                    <div className="bg-amber-500/10 border border-amber-500/30 text-amber-200 rounded-xl p-3 text-xs flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-bold block">הודעת מערכת:</span>
                        <span>{errorMessage}</span>
                      </div>
                    </div>
                  )}

                  <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-[11px] text-slate-400 space-y-1">
                    <div className="flex items-center gap-1.5 font-bold text-slate-300">
                      <Crown className="w-3.5 h-3.5 text-amber-400" />
                      <span>זיהוי אוטומטי של מנהל המאסטר</span>
                    </div>
                    <p>
                      כניסה עם הכתובת <strong>{MASTER_ADMIN_EMAIL}</strong> מעניקה מיידית גישת ניהול עליונה לכלל העסקים.
                    </p>
                  </div>
                </div>
              )}

              {/* Tab 2: Master Admin 1-Click Fast Access */}
              {activeLoginTab === 'master' && (
                <div className="space-y-4">
                  <div className="bg-amber-500/10 border border-amber-500/30 rounded-2xl p-4 text-xs space-y-2">
                    <div className="flex items-center gap-2">
                      <Crown className="w-5 h-5 text-amber-400" />
                      <span className="font-black text-amber-300 text-sm">כניסת מנהל מאסטר עליון</span>
                    </div>
                    <p className="text-slate-300 text-xs">
                      משתמש מאסטר מוגדר: <strong>טל אליהו</strong> (<span className="font-mono text-indigo-300">{MASTER_ADMIN_EMAIL}</span>).
                      לחיצה על הכפתור למטה מפעילה הרשאות מלאות ללא תלות בחסימת חלונות קופצים.
                    </p>
                  </div>

                  <button
                    onClick={handleMasterDemoLogin}
                    className="w-full bg-linear-to-r from-amber-500 via-amber-600 to-amber-500 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-black py-3.5 px-4 rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 cursor-pointer min-h-[44px]"
                  >
                    <Crown className="w-4 h-4" />
                    <span>התחבר עכשיו כמנהל מאסטר (טל אליהו)</span>
                  </button>
                </div>
              )}

              {/* Tab 3: Business Owner Fast Switcher */}
              {activeLoginTab === 'business' && (
                <div className="space-y-4 text-xs">
                  <p className="text-slate-300">
                    בחר את אחד מבעלי העסקים הרשומים במערכת TALTOR כדי להיכנס ישירות ללוח הבקרה שלהם ולבדוק את מגבלות החבילה (BASIC, PRO או ULTIMATE):
                  </p>

                  <div className="space-y-2">
                    <label className="block font-bold text-slate-300">בחר עסק קיים:</label>
                    <select
                      value={selectedBizId}
                      onChange={(e) => setSelectedBizId(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 text-white rounded-xl p-3 text-xs font-semibold focus:ring-2 focus:ring-indigo-500"
                    >
                      {businesses.map((biz) => (
                        <option key={biz.id} value={biz.id}>
                          {biz.name} — {biz.ownerName} ({biz.plan} • ₪{biz.monthlyFee}/חודש)
                        </option>
                      ))}
                    </select>
                  </div>

                  <button
                    onClick={handleBusinessDemoLogin}
                    className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-3.5 px-4 rounded-xl transition-all flex items-center justify-center gap-2 shadow-md shadow-indigo-600/30 cursor-pointer min-h-[44px]"
                  >
                    <Briefcase className="w-4 h-4" />
                    <span>התחבר כבעל העסק הנבחר</span>
                  </button>
                </div>
              )}

              {/* Tab 4: Client Portal Fast Access */}
              {activeLoginTab === 'client' && (
                <div className="space-y-4 text-xs">
                  <p className="text-slate-300">
                    כניסה ישירה לפורטל לקוחות הקצה המאובטח — מאפשר ללקוחות לתאם פגישות, לצפות במסמכים ולשלם דרישות תשלום:
                  </p>

                  <div className="space-y-2">
                    <label className="block font-bold text-slate-300">בחר לקוח לדוגמה:</label>
                    <select
                      value={selectedClientId}
                      onChange={(e) => setSelectedClientId(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 text-white rounded-xl p-3 text-xs font-semibold focus:ring-2 focus:ring-emerald-500"
                    >
                      {clients.map((c) => {
                        const biz = businesses.find((b) => b.id === c.businessId);
                        return (
                          <option key={c.id} value={c.id}>
                            {c.name} ({biz?.name || 'עסק'}) — טלפון: {c.phone}
                          </option>
                        );
                      })}
                    </select>
                  </div>

                  <button
                    onClick={handleClientPortalLogin}
                    className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3.5 px-4 rounded-xl transition-all flex items-center justify-center gap-2 shadow-md shadow-emerald-600/30 cursor-pointer min-h-[44px]"
                  >
                    <User className="w-4 h-4" />
                    <span>כניסה לפורטל הלקוח הנבחר</span>
                  </button>
                </div>
              )}

              {/* Quick direct continue link */}
              {onDismiss && (
                <div className="pt-2 text-center">
                  <button
                    onClick={onDismiss}
                    className="text-xs text-indigo-300 hover:text-indigo-200 font-semibold underline"
                  >
                    מעבר ישיר לתצוגת המערכת הפעילה
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950/60 py-4 px-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="font-extrabold text-slate-300">TALTOR CRM CLOUD</span>
            <span>•</span>
            <span>פלטפורמת ניהול לקוחות ב-3 שכבות הרשאה</span>
          </div>
          <div className="flex items-center gap-3 text-slate-500">
            <span>טל אליהו — מנהל מאסטר</span>
            <span>•</span>
            <span>מוגן ע״י Firebase Firestore</span>
          </div>
        </div>
      </footer>
    </div>
  );
};
