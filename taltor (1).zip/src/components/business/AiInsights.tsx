import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Sparkles,
  Lock,
  AlertTriangle,
  HeartHandshake,
  Star,
  Send,
  MessageCircle,
  TrendingUp,
  ShieldAlert,
  Check,
} from 'lucide-react';

export const AiInsights: React.FC<{ onOpenUpgrade: () => void }> = ({ onOpenUpgrade }) => {
  const { currentPlanFeatures, businessClients, currentBusiness } = useApp();

  const [simulatedMessage, setSimulatedMessage] = useState<{
    clientName: string;
    phone: string;
    text: string;
  } | null>(null);

  const isLocked = !currentPlanFeatures.hasAiInsights;

  if (isLocked) {
    return (
      <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center max-w-2xl mx-auto my-12 shadow-sm">
        <div className="w-14 h-14 bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-amber-200">
          <Sparkles className="w-7 h-7" />
        </div>
        <span className="text-xs font-bold uppercase tracking-wider text-amber-700 bg-amber-100 px-3 py-1 rounded-full border border-amber-300">
          זמין בלעדית בחבילת ULTIMATE
        </span>
        <h3 className="text-xl font-bold text-slate-900 mt-3 mb-2">
          תובנות AI, חיזוי נטישה ומועדון לקוחות VIP
        </h3>
        <p className="text-sm text-slate-600 mb-6 leading-relaxed">
          אלגוריתם חכם המנתח את תדירות התקשורת, שביעות הרצון והיקף הפעילות. המערכת מתריעה אוטומטית על לקוחות בסיכון נטישה ומייצרת פניות שימור מותאמות אישית בלחיצה אחת.
        </p>
        <button
          onClick={onOpenUpgrade}
          className="inline-flex items-center gap-2 bg-linear-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-bold px-6 py-2.5 rounded-xl text-sm transition-all shadow-md shadow-amber-500/20"
        >
          <Sparkles className="w-4 h-4 text-amber-100" />
          <span>שדרג עכשיו לחבילת ULTIMATE</span>
        </button>
      </div>
    );
  }

  // Churn risk clients
  const highRiskClients = businessClients.filter((c) => c.churnRisk === 'high');
  const mediumRiskClients = businessClients.filter((c) => c.churnRisk === 'medium');
  const vipClients = businessClients.filter((c) => c.vipStatus);

  const generateReEngagementMessage = (clientName: string, phone: string) => {
    const text = `היי ${clientName}, מה שלומך? עבר קצת זמן מאז שיחתנו האחרונה ב-${currentBusiness?.name}. רציתי לבדוק איך הדברים מתקדמים אצלך והאם תרצה שנקבע שיחת עדכון קצרה השבוע.`;
    setSimulatedMessage({ clientName, phone, text });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-extrabold text-slate-900">בינה מלאכותית ושימור לקוחות</h2>
            <span className="text-xs font-bold bg-amber-100 text-amber-900 px-2.5 py-0.5 rounded-full border border-amber-300">
              AI Retention Engine
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            זיהוי פרואקטיבי של לקוחות בסיכון, ניתוח מדדי נאמנות והמלצות פעולה למינוף עסקאות.
          </p>
        </div>
      </div>

      {/* Main AI Insights Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Risk Radar */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-red-100 text-red-700">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-slate-900 text-sm">ראדאר סיכון נטישה (Churn Risk)</h3>
                <span className="text-[11px] text-slate-500">
                  {highRiskClients.length} לקוחות דורשים תשומת לב מיידית
                </span>
              </div>
            </div>
          </div>

          <div className="space-y-3 pt-2">
            {highRiskClients.length === 0 ? (
              <div className="p-4 bg-emerald-50 text-emerald-800 rounded-xl text-xs flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-600" />
                <span>כל הלקוחות נמצאים ברמת תקשורת תקינה ובטוחה.</span>
              </div>
            ) : (
              highRiskClients.map((client) => (
                <div
                  key={client.id}
                  className="bg-red-50/50 border border-red-200 rounded-xl p-3.5 text-xs flex items-center justify-between gap-3"
                >
                  <div>
                    <span className="font-bold text-slate-900 block text-xs">{client.name}</span>
                    <span className="text-red-700 text-[11px]">
                      קשר אחרון: {client.lastContactDate} • סיכון גבוה
                    </span>
                  </div>

                  <button
                    onClick={() => generateReEngagementMessage(client.name, client.phone)}
                    className="bg-red-600 hover:bg-red-700 text-white font-bold px-3 py-1.5 rounded-lg text-[11px] transition-colors shadow-2xs shrink-0"
                  >
                    הפעל פניית שימור AI
                  </button>
                </div>
              ))
            )}

            {mediumRiskClients.map((client) => (
              <div
                key={client.id}
                className="bg-amber-50/40 border border-amber-200 rounded-xl p-3 text-xs flex items-center justify-between gap-3"
              >
                <div>
                  <span className="font-bold text-slate-900 block text-xs">{client.name}</span>
                  <span className="text-amber-800 text-[11px]">
                    קשר אחרון: {client.lastContactDate} • סיכון בינוני
                  </span>
                </div>
                <button
                  onClick={() => generateReEngagementMessage(client.name, client.phone)}
                  className="text-amber-800 hover:bg-amber-100 font-semibold px-2.5 py-1 rounded-lg text-[11px] transition-colors"
                >
                  הצע פנייה
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* VIP & Upsell Club */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-amber-100 text-amber-700">
                <Star className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-slate-900 text-sm">מועדון לקוחות VIP והזדמנויות צמיחה</h3>
                <span className="text-[11px] text-slate-500">
                  {vipClients.length} לקוחות מועדפים עם פוטנציאל הרחבת פעילות
                </span>
              </div>
            </div>
          </div>

          <div className="space-y-3 pt-2">
            {vipClients.map((client) => (
              <div
                key={client.id}
                className="bg-amber-50/30 border border-amber-200 rounded-xl p-3.5 text-xs flex items-center justify-between"
              >
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-slate-900 text-xs">{client.name}</span>
                    <span className="bg-amber-200 text-amber-900 text-[10px] font-bold px-1.5 py-0.2 rounded">
                      VIP
                    </span>
                  </div>
                  <span className="text-slate-500 text-[11px]">
                    ערך כולל: ₪{(client.dealValue || 0).toLocaleString()} • מדד שביעות רצון: 10/10
                  </span>
                </div>

                <div className="text-left">
                  <span className="text-[11px] text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    מוכן להרחבת ריטיינר
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Simulated AI Engagement Drawer / Modal */}
      {simulatedMessage && (
        <div className="bg-linear-to-r from-indigo-900 to-slate-900 text-white rounded-2xl p-6 shadow-xl border border-indigo-700 animate-in fade-in">
          <div className="flex items-start justify-between mb-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-400" />
              <h4 className="font-bold text-sm">
                הודעת שימור מותאמת אישית ל-{simulatedMessage.clientName}
              </h4>
            </div>
            <button
              onClick={() => setSimulatedMessage(null)}
              className="text-indigo-300 hover:text-white text-xs"
            >
              סגור
            </button>
          </div>

          <div className="bg-white/10 rounded-xl p-4 text-xs leading-relaxed text-indigo-100 font-mono mb-4">
            "{simulatedMessage.text}"
          </div>

          <div className="flex items-center gap-3">
            <a
              href={`https://wa.me/972${simulatedMessage.phone.replace(/[^0-9]/g, '').replace(/^0/, '')}?text=${encodeURIComponent(
                simulatedMessage.text
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-5 py-2.5 rounded-xl text-xs transition-colors flex items-center gap-2 shadow-xs"
            >
              <MessageCircle className="w-4 h-4" />
              <span>שלח כעת ב-WhatsApp ישירות ללקוח</span>
            </a>
            <button
              onClick={() => {
                navigator.clipboard.writeText(simulatedMessage.text);
                alert('ההודעה הועתקה ללוח!');
              }}
              className="bg-white/15 hover:bg-white/20 text-white font-medium px-4 py-2.5 rounded-xl text-xs transition-colors"
            >
              העתק נוסח
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
